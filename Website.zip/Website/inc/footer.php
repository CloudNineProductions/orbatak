

<?php require_once("config.php"); ?>


	</div>
	
		<div class="footer"> 
		
			<a href="<?php echo BASE_URL; ?>music/">Music</a>
			<a href="<?php echo BASE_URL; ?>about/">About</a>
			<a href="<?php echo BASE_URL; ?>contact/">Contact</a>
				
			
			<p>Created by Cloud Edwards &copy; <?php  echo date('Y'); ?></p>
		</div>

	</body>
</html>