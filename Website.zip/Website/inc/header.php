<!DOCTYPE html>

<?php require_once("config.php"); ?>

<html>
	<body>
	
		<head>
			<title> <?php echo $pageTitle ?></title>
			<link href='http://fonts.googleapis.com/css?family=Audiowide' rel='stylesheet' type='text/css'>
			<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
			<link rel="icon" href="/favicon.ico" type="image/x-icon">
			<link href='http://fonts.googleapis.com/css?family=Dosis' rel='stylesheet' type='text/css'>
			<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL; ?>css/style1.css"></link>
		</head>
		<div class="header" > 
			<a href="<?php echo BASE_URL; ?>">
				<image class="banner-img" src="<?php echo BASE_URL; ?>
					img/banner-logo.png" alt="Metalic letters spelling Orbatak"></image>
			</a>
		</div>
		<div class="nav">
			<a class="music<?php if ($section == "music"){echo "on";} ?>" href="<?php echo BASE_URL; ?>music/">Music</a>
			<a class="about<?php if ($section == "about"){echo "on";} ?>" href="<?php echo BASE_URL; ?>about/">About</a>
			<a class="contact<?php if ($section == "contact"){echo "on";} ?>" href="<?php echo BASE_URL; ?>contact/">Contact</a>
			<p></p>
		</div>
		
		
	<div id="content">