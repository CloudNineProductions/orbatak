<?php 
	define("BASE_URL", "/");
	define("ROOT_PATH", $_SERVER["DOCUMENT_ROOT"]."/");
 ?>